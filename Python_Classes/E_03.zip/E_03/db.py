# Dictionary with multiple students
my_dict = {
    'Himanshu': {
        'Name': 'Himanshu',
        'RollNo.': 1,
        'Address': {'City': 'Mohali', 'Pin': 160056, 'State': 'Punjab'},
        'Age': 25,
        'Gender': 'Male',
        'Contact': {'Phone': '1234567890', 'Email': 'himanshu@example.com'},
        'Subjects': ['Math', 'Science', 'English'],
        'Marks': (85, 90, 95)
    },
    'Anjali': {
        'Name': 'Anjali',
        'RollNo.': 2,
        'Address': {'City': 'Chandigarh', 'Pin': 160020, 'State': 'Punjab'},
        'Age': 22,
        'Gender': 'Female',
        'Contact': {'Phone': '0987654321', 'Email': 'anjali@example.com'},
        'Subjects': ['Math', 'Biology', 'English'],
        'Marks': (88, 91, 85)
    },
    'Ravi': {
        'Name': 'Ravi',
        'RollNo.': 3,
        'Address': {'City': 'Ludhiana', 'Pin': 141001, 'State': 'Punjab'},
        'Age': 24,
        'Gender': 'Male',
        'Contact': {'Phone': '1122334455', 'Email': 'ravi@example.com'},
        'Subjects': ['Physics', 'Chemistry', 'English'],
        'Marks': (92, 89, 94)
    }
}
