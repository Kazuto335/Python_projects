from db import my_dict
# The Above code help you to use the data of some other file in your file

print(my_dict)

# TODO 1: Find How many student live in Mohali and Chandigarh

# TODO 2: Show the marks of each student in English.
# Output Must be like this: <Student Name> got <Marks> in English.


# TODO 3: Show the marks in Maths.
# Output Must be like this: <Student Name> got <Marks> in English.
